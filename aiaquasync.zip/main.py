import streamlit as st
import pandas as pd
import numpy as np
import sqlite3
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline

# Create or connect to the SQLite database
conn = sqlite3.connect('user_data.db')
cursor = conn.cursor()

# Create a user_data table if not exists
cursor.execute('''
    CREATE TABLE IF NOT EXISTS user_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        age INTEGER,
        weight INTEGER,
        activity_level TEXT,
        climate TEXT,
        day INTEGER,
        water_intake INTEGER
    )
''')
conn.commit()

def get_personalized_recommendation(user_data):
    # Dummy polynomial regression model for demonstration purposes
    X = user_data[['age', 'weight', 'day']]
    y = user_data['water_intake']

    degree = 2  # You can adjust the degree based on your data
    model = make_pipeline(PolynomialFeatures(degree), LinearRegression())
    model.fit(X, y)

    user_input = user_data[['age', 'weight', 'day']]
    recommendation = model.predict(user_input)

    # Make a recommendation based on the prediction (replace with your actual logic)
    if recommendation[-1] > 2000:
        result = "You are doing well in maintaining hydration!"
    else:
        result = "Consider adjusting your water intake for better hydration."

    return result


# Streamlit App
st.title("Aqua Sync AI - Personalized Hydration Management")

# User Input Section
st.sidebar.header("User Information")
age = st.sidebar.number_input("Age", min_value=1, max_value=100, value=25)
weight = st.sidebar.number_input("Weight (kg)", min_value=1, max_value=300, value=70)
activity_level = st.sidebar.selectbox("Activity Level", ["Low", "Moderate", "High"], index=1)
climate = st.sidebar.selectbox("Climate", ["Hot", "Moderate", "Cold"], index=1)

# Input for a single day water intake
day = st.number_input("Enter the day for water intake", min_value=1, value=1)
water_intake = st.number_input(f"Water Intake for Day {day} (ml)", min_value=0, value=2000)

# Save user data to SQLite database
cursor.execute('''
    INSERT INTO user_data (age, weight, activity_level, climate, day, water_intake)
    VALUES (?, ?, ?, ?, ?, ?)
''', (age, weight, activity_level, climate, day, water_intake))

conn.commit()

# Analysis and Prediction Section
st.header("Analysis and Prediction")
df_user_data = pd.DataFrame({"age": [age], "weight": [weight], "day": [day], "water_intake": [water_intake]})
recommendation = get_personalized_recommendation(df_user_data)
st.write("Based on the analysis of your data:")
st.write(recommendation)

# Close the SQLite connection
conn.close()
